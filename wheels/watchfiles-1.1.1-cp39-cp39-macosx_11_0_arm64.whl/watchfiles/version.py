from ._rust_notify import __version__

__all__ = ('VERSION',)

VERSION = __version__
